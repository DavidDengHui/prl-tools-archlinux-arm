//
//  Copyright (c) 2021 Parallels International GmbH. All rights reserved.
//

#pragma once

#define VIRTIO_SOCKET_PORT_CPTOOL 9001
#define VIRTIO_SOCKET_PORT_TOOLSCENTER 9002
#define VIRTIO_SOCKET_PORT_EXEC 9003

